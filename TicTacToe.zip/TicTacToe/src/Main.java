//Das ist die Startklasse
public class Main {

	public static void main(String[] args) {
		Gui G1 = new Gui ();

	}
}
